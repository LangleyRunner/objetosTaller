public class Automovil {
    String marca;
    String modelo;
    String color = "Negro"; //Es una forma de asignar valores
    double cilindraje; //Tipo de dato nativo con minúscula.
}
/* Formas de asignar valores:
 1. Creando un objeto.
 2. Desde la clase
 */


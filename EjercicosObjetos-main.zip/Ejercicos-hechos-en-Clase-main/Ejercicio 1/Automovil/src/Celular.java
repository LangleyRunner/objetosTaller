public class Celular {
     String marca;
     String modelo;
     String color;
     int almacenamiento;
}
